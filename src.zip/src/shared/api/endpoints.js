export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

const withDefault = (envValue, fallback) => envValue || fallback;

export const API_ENDPOINTS = {
  auth: {
    login: withDefault(import.meta.env.VITE_LOGIN_ENDPOINT, '/auth/login'),
    register: withDefault(import.meta.env.VITE_REGISTER_ENDPOINT, '/auth/register'),
    logout: withDefault(import.meta.env.VITE_LOGOUT_ENDPOINT, '/auth/logout'),
    me: withDefault(import.meta.env.VITE_AUTH_ME_ENDPOINT, '/auth/me'),
    refresh: withDefault(import.meta.env.VITE_REFRESH_ENDPOINT, '/auth/refresh')
  },
  home: {
    popularCategories: withDefault(import.meta.env.VITE_HOME_POPULAR_CATEGORIES_ENDPOINT, '/categories/popular'),
    categoryOverview: withDefault(import.meta.env.VITE_HOME_CATEGORY_OVERVIEW_ENDPOINT, '/categories/overview'),
    featuredTestimonials: withDefault(import.meta.env.VITE_HOME_TESTIMONIALS_ENDPOINT, '/testimonials/featured'),
    featuredFreelancerCategories: withDefault(
      import.meta.env.VITE_HOME_FREELANCER_CATEGORIES_ENDPOINT,
      '/freelancers/featured/categories'
    ),
    featuredFreelancers: withDefault(import.meta.env.VITE_HOME_FREELANCERS_ENDPOINT, '/freelancers/featured'),
    pricingPlans: withDefault(import.meta.env.VITE_HOME_PRICING_ENDPOINT, '/plans'),
    latestBlogs: withDefault(import.meta.env.VITE_HOME_BLOGS_ENDPOINT, '/blogs/latest?limit=3')
  },
  profile: {
    me: withDefault(import.meta.env.VITE_PROFILE_ME_ENDPOINT, '/profile/me'),
    update: withDefault(import.meta.env.VITE_PROFILE_UPDATE_ENDPOINT, '/profile/me'),
    summary: withDefault(import.meta.env.VITE_PROFILE_SUMMARY_ENDPOINT, '/profile/dashboard-summary'),
    tasks: withDefault(import.meta.env.VITE_PROFILE_TASKS_ENDPOINT, '/profile/tasks'),
    listings: withDefault(import.meta.env.VITE_PROFILE_LISTINGS_ENDPOINT, '/profile/listings'),
    proposals: withDefault(import.meta.env.VITE_PROFILE_PROPOSALS_ENDPOINT, '/profile/proposals'),
    reviews: withDefault(import.meta.env.VITE_PROFILE_REVIEWS_ENDPOINT, '/profile/reviews'),
    saved: withDefault(import.meta.env.VITE_PROFILE_SAVED_ENDPOINT, '/profile/saved'),
    notifications: withDefault(import.meta.env.VITE_PROFILE_NOTIFICATIONS_ENDPOINT, '/profile/notifications'),
    messages: withDefault(import.meta.env.VITE_PROFILE_MESSAGES_ENDPOINT, '/profile/messages')
  }
};

export const homeEndpoints = API_ENDPOINTS.home;
export const authEndpoints = API_ENDPOINTS.auth;

export function buildProfileListingStatusEndpoint(listingId) {
  return `${API_ENDPOINTS.profile.listings}/${listingId}/status`;
}

export function buildProfileProposalStatusEndpoint(proposalId) {
  return `${API_ENDPOINTS.profile.proposals}/${proposalId}/status`;
}

export function buildProfileSavedItemEndpoint(savedItemId) {
  return `${API_ENDPOINTS.profile.saved}/${savedItemId}`;
}

export function buildProfileNotificationReadEndpoint(notificationId) {
  return `${API_ENDPOINTS.profile.notifications}/${notificationId}/read`;
}

export function buildProfileMessageReadEndpoint(messageId) {
  return `${API_ENDPOINTS.profile.messages}/${messageId}/read`;
}
