/**
 * @typedef {Object} LoginCredentials
 * @property {string} email
 * @property {string} password
 * @property {boolean} rememberMe
 */

/**
 * @typedef {Object} AuthSession
 * @property {string | null} accessToken
 * @property {string | null} refreshToken
 * @property {string | null} csrfToken
 * @property {string | null} expiresAt
 * @property {'token' | 'cookie'} authType
 * @property {boolean} rememberMe
 */

export {};
