export const TEST_LOGIN_CREDENTIALS = {
  email: 'demo@workreap.com',
  password: 'google'
};
